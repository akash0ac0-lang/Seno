package com.seno.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 70, 40, 40)
        }
        val title = TextView(this).apply {
            text = "Seno"
            textSize = 34f
        }
        status = TextView(this).apply {
            text = "Bolo, Seno sun raha hai..."
            textSize = 18f
            setPadding(0, 25, 0, 35)
        }
        val button = Button(this).apply {
            text = "🎙️ Bolo"
            setOnClickListener { listen() }
        }
        box.addView(title); box.addView(status); box.addView(button)
        setContentView(box)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Is phone par voice recognition available nahi hai.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                status.text = "Tumne kaha: $text"
                handleCommand(text)
            }
            override fun onError(error: Int) { status.text = "Dobara bolo."; }
            override fun onReadyForSpeech(p0: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(p0: Float) {}
            override fun onBufferReceived(p0: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p0: Bundle?) {}
            override fun onEvent(p0: Int, p1: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Seno ko bolo...")
        }
        recognizer!!.startListening(intent)
    }

    private fun handleCommand(command: String) {
        val c = command.lowercase(Locale.getDefault())
        when {
            c.contains("calculator") || c.contains("calculate") || c.contains("hisab") ->
                speak("Calculator command samajh gaya. AI actions next version mein add karenge.")
            c.contains("message") || c.contains("msg") || c.contains("whatsapp") ->
                speak("Message command samajh gaya. Send karne se pehle confirmation rakhenge.")
            c.contains("poster") || c.contains("image") || c.contains("photo") ->
                speak("Image banane wala action next version mein connect kiya ja sakta hai.")
            else -> speak("Maine suna: $command. AI brain connect karne ke baad main iska proper kaam karwaunga.")
        }
    }

    private fun speak(text: String) {
        status.text = text
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "seno")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts.stop(); tts.shutdown(); super.onDestroy()
    }
}
