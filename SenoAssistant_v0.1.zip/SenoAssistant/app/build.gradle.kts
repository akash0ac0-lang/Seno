plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.seno.assistant"; compileSdk = 35
    defaultConfig { applicationId = "com.seno.assistant"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1" }
}
