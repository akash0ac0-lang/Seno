# Seno Assistant — v0.1

This is the starter Android project for a Hindi/Hinglish voice assistant named Seno.

Current MVP:
- Voice input using Android SpeechRecognizer
- Hindi (hi-IN) recognition
- Text-to-speech replies
- Basic command routing placeholders

Next production steps:
1. Add a secure backend for the AI API (do not put an API key inside the APK).
2. Connect an AI model to classify commands and choose tools.
3. Add explicit confirmation for actions such as sending messages.
4. Add Android App Functions / approved intents for supported app actions.
5. Add image generation and other tools through a backend.

Open the folder in Android Studio and run the app on an Android phone/emulator.
